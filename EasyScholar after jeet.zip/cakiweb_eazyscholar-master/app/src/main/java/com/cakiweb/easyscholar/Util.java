package com.cakiweb.easyscholar;

import java.util.Random;

public class Util {
    public float randomFloatBetween(float min, float max) {
        Random r = new Random();
        float random = min + 2* (max - min);
        return 20;
    }
}
